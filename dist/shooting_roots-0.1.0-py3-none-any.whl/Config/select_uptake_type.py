def select_uptake_type(ind):
    if ind == 0:
        return 'Feddes'
    elif ind == 1:
        return 'Li'
